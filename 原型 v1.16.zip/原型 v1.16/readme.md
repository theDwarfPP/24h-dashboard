# Prototype Workspace

## 目录结构

### codebase (代码目录)

代码文件，包含原型的完整代码实现。

```
├── src/
│   ├── components/
│   │   ├── DataGrid.tsx
│   │   ├── DatePicker.tsx
│   │   ├── Header.tsx
│   │   ├── KeyMetrics.tsx
│   │   ├── TabsAndFilters.tsx
│   │   └── TrendChart.tsx
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   └── Dashboard.tsx
├── dependencies.json
├── meta.json
└── prototype-route.json
```

### notebook (代码生成时候的笔记)

笔记文件，记录代码生成过程中的思考和决策。

```
└── plan.md
```