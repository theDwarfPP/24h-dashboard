import React, { useMemo } from 'react';
import { ChevronUp, HelpCircle, Edit2, ChevronDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSearchParams } from 'react-router-dom';

export const TrendChart = () => {
  const [searchParams] = useSearchParams();
  const startDate = searchParams.get('startDate') || '2026-03-17';
  const endDate = searchParams.get('endDate') || '2026-03-21';

  const isSingleDay = startDate === endDate;

  const chartData = useMemo(() => {
    const data = [];
    
    if (isSingleDay) {
      // Generate hourly data for a single day
      for (let i = 0; i <= 23; i++) {
        const hourStr = `${i.toString().padStart(2, '0')}:00`;
        data.push({
          time: hourStr,
          roi1: i === 0 ? 0 : (Math.random() * 0.5 + 0.2), // Keep it low to match image-7
          roi2: null,
          roi3: null,
        });
      }
    } else {
      // Generate daily data for date range
      const start = new Date(startDate);
      const end = new Date(endDate);
      let current = new Date(start);
      while (current <= end) {
        const dateStr = current.toISOString().split('T')[0];
        data.push({
          time: dateStr,
          roi1: 1.5 + Math.random(),
          roi2: Math.random() > 0.5 ? 2.0 + Math.random() : null,
          roi3: Math.random() > 0.5 ? 1.8 + Math.random() : null,
        });
        current.setDate(current.getDate() + 1);
      }
    }
    
    return data;
  }, [startDate, endDate, isSingleDay]);

  return (
    <div className="px-6 py-5 pb-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-base font-medium text-gray-900">趋势对比</h2>
          <div className="w-px h-3 bg-gray-300"></div>
          <label className="flex items-center space-x-2 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
            <span className="text-sm text-gray-600">模拟全域综合指标</span>
            <HelpCircle className="w-3.5 h-3.5 text-gray-400" />
          </label>
          <div className="flex items-center space-x-1 text-sm text-gray-600">
            <span>模拟成本项: 电商技术服务费</span>
            <Edit2 className="w-3.5 h-3.5 text-gray-400 cursor-pointer" />
          </div>
        </div>
        <div className="flex items-center space-x-1 text-sm text-gray-500 cursor-pointer hover:text-gray-700">
          <ChevronUp className="w-4 h-4" />
          <span>收起对比</span>
        </div>
      </div>

      <div className="flex items-center justify-center space-x-8 mb-6">
        <div className="flex items-center space-x-2 cursor-pointer">
          <div className="w-3 h-0.5 bg-cyan-400"></div>
          <span className="text-sm text-gray-600">综合ROI (24小时)</span>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
        <div className="flex items-center space-x-2 cursor-pointer">
          <div className="w-3 h-0.5 bg-gray-300 border-t border-dashed border-gray-400"></div>
          <span className="text-sm text-gray-600">综合ROI (24小时) - 回流中</span>
        </div>
        <div className="flex items-center space-x-2 cursor-pointer">
          <div className="w-3 h-0.5 bg-blue-600"></div>
          <span className="text-sm text-gray-600">预估综合ROI (24小时)</span>
          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
        </div>
      </div>

      <div className="relative">
        <div className="text-xs text-gray-400 absolute -top-4 left-0">综合ROI</div>
        <div className="h-[300px] w-full mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis 
                dataKey="time" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9ca3af', fontSize: 12 }} 
                dy={10}
                interval={isSingleDay ? 0 : 'preserveStartEnd'}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9ca3af', fontSize: 12 }}
                domain={[0, isSingleDay ? 1 : 3]}
                ticks={isSingleDay ? [0, 0.25, 0.5, 0.75, 1] : [0.00, 1.50, 2.00, 2.50, 3.00]}
                tickFormatter={(val) => isSingleDay ? val.toString() : val.toFixed(2)}
              />
              <Tooltip />
              <Line type="monotone" dataKey="roi1" stroke="#06b6d4" strokeWidth={2} dot={false} />
              {!isSingleDay && (
                <>
                  <Line type="monotone" dataKey="roi2" stroke="#9ca3af" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                  <Line type="monotone" dataKey="roi3" stroke="#2563eb" strokeWidth={2} dot={false} />
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      <div className="flex items-center mt-4">
        <div className="text-xs text-gray-500 w-12">投放<br/>动作</div>
        <div className="flex-1 border-t border-dashed border-gray-200 ml-2"></div>
      </div>
    </div>
  );
};