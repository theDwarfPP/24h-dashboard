import React from 'react';
import { HelpCircle, Settings2 } from 'lucide-react';

const data = [
  { title: '综合ROI (24小时)', value: '3.99', change: '+1.65%', tag: '数据回流中', tagColor: 'gray', bg: 'bg-teal-50/50' },
  { title: '预估综合ROI (24小时)', value: '2.58', change: '+1.38%', tag: '推荐关注', tagColor: 'blue', bg: 'bg-blue-50/50' },
  { title: '24小时结算金额(元)', value: '3,200.01', change: '+69.65%', bg: 'bg-gray-50' },
  { title: '净成交金额', value: '3,300.99', change: '+69.65%', bg: 'bg-gray-50' },
  { title: '综合订单成本(元)', value: '13,118.90', change: '+69.65%', bg: 'bg-gray-50' },
  { title: '综合成本(元)', value: '1,162.79', change: '+1.38%', bg: 'bg-gray-50' },
  { title: '24小时内退款率', value: '30.12%', change: '+69.65%', bg: 'bg-gray-50' },
  { title: '整体成交金额(元)', value: '7,710.00', change: '+69.65%', bg: 'bg-gray-50' },
];

export const DataGrid = () => {
  return (
    <div className="px-6 py-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-base font-medium text-gray-900">数据概览</h2>
          <label className="flex items-center space-x-2 cursor-pointer">
            <input type="checkbox" className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
            <span className="text-sm text-gray-600">只看基础数据</span>
            <HelpCircle className="w-3.5 h-3.5 text-gray-400" />
          </label>
        </div>
        <button className="p-1.5 bg-gray-50 border border-gray-200 rounded hover:bg-gray-100">
          <Settings2 className="w-4 h-4 text-gray-600" />
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {data.map((item, index) => (
          <div key={index} className={`${item.bg} rounded-lg p-4`}>
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-sm text-gray-700">{item.title}</span>
              {item.tag && (
                <span className={`text-[10px] px-1 rounded border ${
                  item.tagColor === 'blue' ? 'text-blue-600 border-blue-200 bg-blue-50' : 'text-gray-500 border-gray-200 bg-white'
                }`}>
                  {item.tag}
                </span>
              )}
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-xl font-semibold text-gray-900">{item.value}</span>
              <span className="text-sm text-red-500">{item.change}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};