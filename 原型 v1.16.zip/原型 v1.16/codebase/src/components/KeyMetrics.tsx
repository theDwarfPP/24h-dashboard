import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

export const KeyMetrics = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const dataType = searchParams.get('dataType') || 'estimated';
  const isRealData = dataType === 'real';
  
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (type: 'estimated' | 'real') => {
    setSearchParams({ dataType: type });
    setIsDropdownOpen(false);
  };

  return (
    <div className="px-6 py-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <h2 className="text-base font-medium text-gray-900">重点数据概览</h2>
          <div className="w-px h-3 bg-gray-300 mx-2"></div>
          
          <div className="relative" ref={dropdownRef}>
            <div 
              className="flex items-center space-x-1 cursor-pointer hover:bg-gray-50 px-1.5 py-1 rounded"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            >
              <span className="text-sm text-gray-800">{isRealData ? '真实数据' : '预估数据'}</span>
              {!isRealData && (
                <span className="text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">推荐关注</span>
              )}
              <ChevronDown className="w-4 h-4 text-gray-500" />
            </div>
            
            {isDropdownOpen && (
              <div className="absolute top-full left-0 mt-1 w-32 bg-white border border-gray-200 rounded-md shadow-lg z-10 py-1">
                <div 
                  className={`px-3 py-2 text-sm cursor-pointer hover:bg-gray-50 ${!isRealData ? 'text-blue-600 bg-blue-50/50' : 'text-gray-700'}`}
                  onClick={() => handleSelect('estimated')}
                >
                  预估数据
                </div>
                <div 
                  className={`px-3 py-2 text-sm cursor-pointer hover:bg-gray-50 ${isRealData ? 'text-blue-600 bg-blue-50/50' : 'text-gray-700'}`}
                  onClick={() => handleSelect('real')}
                >
                  真实数据
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center text-sm text-gray-600">
          <div className="w-5 h-5 rounded-full bg-yellow-400 text-white flex items-center justify-center text-xs mr-2 shadow-sm">¥</div>
          统计周期内，预估可减免电商技术服务费 <span className="text-orange-500 font-medium ml-1 text-base">3500 元</span>
        </div>
      </div>

      <div className="flex items-stretch gap-6">
        {/* Left Card */}
        <div className="flex-1 bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col shadow-sm">
          <div className="bg-[#f8f9fe] px-4 py-2.5 border-b border-gray-100 flex items-center">
            <span className="text-sm font-medium text-gray-800 border-b border-dashed border-gray-400 pb-0.5">
              {isRealData ? '综合ROI (24小时)' : '预估综合ROI (24小时)'}
            </span>
          </div>
          <div className="p-4 flex items-center space-x-2 flex-1">
            {isRealData ? (
              <>
                <span className="text-2xl font-semibold text-gray-900">3<span className="text-lg">.99</span></span>
                <span className="text-sm text-red-500">+9.65%</span>
              </>
            ) : (
              <>
                <span className="text-2xl font-semibold text-gray-900">2<span className="text-lg">.58</span></span>
                <span className="text-sm text-red-500">+5.89%</span>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 text-gray-600 font-bold text-sm self-center">
          =
        </div>

        {/* Middle Card */}
        {isRealData ? (
          <div className="flex-[2.5] bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col shadow-sm">
            <div className="bg-[#f8f9fe] px-4 py-2.5 border-b border-gray-100 flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-800 border-b border-dashed border-gray-400 pb-0.5">24小时结算金额</span>
              <span className="text-xs text-gray-400 ml-2">真实数据，部分退款未发生，数据虚高</span>
            </div>
            <div className="p-4 flex items-center flex-1">
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-semibold text-gray-900">3,300<span className="text-lg">.99</span></span>
                <span className="text-sm text-red-500">+1.38%</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-[2.5] bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col shadow-sm">
            <div className="bg-[#f8f9fe] px-4 py-2.5 border-b border-gray-100 flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-800 border-b border-dashed border-gray-400 pb-0.5">预估24小时结算金额(元)</span>
              <span className="text-xs text-gray-400 ml-2">根据历史情况，剔除24小时预计退款</span>
              <div className="flex items-center text-xs text-blue-500 cursor-pointer ml-2">
                <div className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white text-[8px] mr-1">?</div>
                什么是预估数据
              </div>
            </div>
            
            <div className="p-4 flex items-center flex-1">
              <div className="flex items-center space-x-2 w-40">
                <span className="text-2xl font-semibold text-gray-900">3,000<span className="text-lg">.01</span></span>
                <span className="text-sm text-red-500">+2.32%</span>
              </div>
              <div className="text-gray-400 font-medium mx-6">=</div>
              <div className="flex items-center space-x-6">
                <div className="flex flex-col">
                  <div className="inline-block border-b border-dashed border-gray-400 pb-0.5 mb-1">
                    <span className="text-xs text-gray-600">整体成交金额(元)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-semibold text-gray-900">3,300<span className="text-sm">.99</span></span>
                    <span className="text-xs text-green-500">-1.22%</span>
                  </div>
                </div>
                <div className="text-gray-400 font-medium">-</div>
                <div className="flex flex-col">
                  <div className="inline-block border-b border-dashed border-gray-400 pb-0.5 mb-1">
                    <span className="text-xs text-gray-600">预估24小时退款(元)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-semibold text-gray-900">300<span className="text-sm">.98</span></span>
                    <span className="text-xs text-red-500">+2.32%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 text-gray-600 font-bold text-sm self-center">
          ÷
        </div>

        {/* Right Card */}
        <div className="flex-1 bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col shadow-sm">
          <div className="bg-[#f8f9fe] px-4 py-2.5 border-b border-gray-100 flex items-center">
            <span className="text-sm font-medium text-gray-800 border-b border-dashed border-gray-400 pb-0.5">
              {isRealData ? '综合营销成本(元)' : '综合成本(元)'}
            </span>
          </div>
          <div className="p-4 flex items-center space-x-2 flex-1">
            <span className="text-2xl font-semibold text-gray-900">1,162<span className="text-lg">.79</span></span>
            <span className="text-sm text-red-500">+1.38%</span>
          </div>
        </div>
      </div>
    </div>
  );
};