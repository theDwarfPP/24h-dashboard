import React from 'react';
import { MoreVertical } from 'lucide-react';

export const Header = () => {
  return (
    <div className="flex items-start justify-between px-6 py-4 bg-white">
      <div className="flex flex-col space-y-3">
        <h1 className="text-xl font-medium text-gray-900">双十一大促口红003色号-出价13测试</h1>
        <div className="flex items-center space-x-4">
          <span className="px-2 py-0.5 text-xs font-medium text-green-600 bg-green-50 rounded-sm">投放中</span>
          <span className="text-sm text-gray-500">ID: 123123123123123131123</span>
          <span className="text-sm text-gray-500 ml-4">每日预算(元): <span className="text-gray-900 font-medium">1,000.00</span></span>
        </div>
      </div>
      <div className="flex items-center space-x-4 mt-1">
        <div className="w-10 h-5 bg-gray-800 rounded-full relative cursor-pointer">
          <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
        </div>
        <MoreVertical className="w-5 h-5 text-gray-500 cursor-pointer" />
      </div>
    </div>
  );
};