import React from 'react';
import { Header } from './components/Header';
import { TabsAndFilters } from './components/TabsAndFilters';
import { KeyMetrics } from './components/KeyMetrics';
import { DataGrid } from './components/DataGrid';
import { TrendChart } from './components/TrendChart';

export const Dashboard = () => {
  return (
    <div className="min-h-screen bg-[#f0f5ff] font-sans pb-8">
      <div className="bg-white">
        <div className="max-w-[1440px] mx-auto">
          <Header />
        </div>
      </div>
      
      <div className="max-w-[1440px] mx-auto px-6 mt-6">
        {/* 视觉整合的统一卡片区域 */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <TabsAndFilters />
          <KeyMetrics />
          <DataGrid />
          <TrendChart />
        </div>
      </div>
    </div>
  );
};