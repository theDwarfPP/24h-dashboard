1. 更新 `DatePicker.tsx`，实现区间选择逻辑（第一次点击选起始日，第二次点击选结束日，同日点击两次选当天）。
2. 在 `DatePicker.tsx` 中根据参考图 `image-6` 渲染日历的选中状态（起始/结束高亮，中间浅色背景）。
3. 更新 `TrendChart.tsx`，根据 `startDate` 和 `endDate` 是否相同，动态切换横坐标轴的显示格式（单日显示分时，跨天显示日期），参考 `image-7`。
4. 更新 `prototype-route.json`，添加单日选择和跨天选择的路由状态。